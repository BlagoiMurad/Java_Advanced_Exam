package fishingPond;

import java.util.ArrayList;
import java.util.List;

public class Pond extends Fish{
    private int capacity;
    private List<Fish> fishes;

    public Pond(int capacity) {
        this.capacity = capacity;
        this.fishes = new ArrayList<>();
    }

    public void addFish(Fish fish) {
        if (fishes.size() < capacity) {
            fishes.add(fish);
        }
    }

    public boolean removeFish(String species) {
        for (Fish fish : fishes) {
            if (fish.getSpecies().equals(species)) {
                fishes.remove(fish);
                return true;
            }
        }
        return false;
    }

    public Fish getOldestFish() {
        if (fishes.isEmpty()) {
            return null;
        }

        Fish oldestFish = fishes.get(0);
        for (Fish fish : fishes) {
            if (fish.getAge() > oldestFish.getAge()) {
                oldestFish = fish;
            }
        }
        return oldestFish;
    }

    public Fish getFish(String species) {
        for (Fish fish : fishes) {
            if (fish.getSpecies().equals(species)) {
                return fish;
            }
        }
        return null;
    }

    public int getCount() {
        return fishes.size();
    }

    public int getVacancies() {
        return capacity - fishes.size();
    }

    public String report() {
        StringBuilder report = new StringBuilder("Fishes in the pond:\n");
        for (Fish fish : fishes) {
            report.append(fish.toString()).append("\n");
        }
        return report.toString().trim();
    }
}

